// declaring variable for the data to be stored in
export class List {
    _id:string="";
    Name:string="";
    Image:string="";
    Feature:Array<object>=[
        {
        Storage:Number,
        Color:String,
        Price:Number
        }
    ];
}
