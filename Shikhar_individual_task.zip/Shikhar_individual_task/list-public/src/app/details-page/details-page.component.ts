import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { List } from '../list';
import { ListServiceService } from '../list-service.service';
import {switchMap} from 'rxjs/operators';
@Component({
  selector: 'app-details-page',
  templateUrl: './details-page.component.html',
  styleUrls: ['./details-page.component.css'],
  providers:[ListServiceService]
})
export class DetailsPageComponent implements OnInit {

  constructor(
    private listserviceservice:ListServiceService,
    private route:ActivatedRoute
  ) { }

  newProduct:List=new List;
  ngOnInit(): void {
    this.route.params.pipe(
    switchMap((params:Params)=>{
        return this.listserviceservice.getSingleProduct(params['listid'])
      }))
      .subscribe((newProduct:any)=>{
        this.newProduct=newProduct;
        this.pageContent.header.title=newProduct.Name;
        this.pageContent.header.img=newProduct.Image;
        this.pageContent.header.body="Details for selected product";
      });

      this.route.params.pipe(
        switchMap((params:Params)=>{
            return this.listserviceservice.deleteProduct(this.newProduct._id)
          }))
          .subscribe(()=>{
          });
      
  }
  deleteProduct(){
    
  }
  pageContent={
    header:{
      title:'',
      body:'',
      img:''
    }
  };
}

