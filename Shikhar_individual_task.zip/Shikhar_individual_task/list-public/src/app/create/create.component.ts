import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { List } from '../list';
import { ListServiceService } from '../list-service.service';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css'],
  providers:[ListServiceService]
})
export class CreateComponent implements OnInit {

  public newProduct:List={
    _id: '',
    Name: '',
    Image: '',
    Feature: []
  }
  url: string | ArrayBuffer | null="";
  formData: any;
  constructor(private listServiceService:ListServiceService) { }

  ngOnInit(): void {
  }

  public createProduct(newProduct:List):void{
    this.listServiceService.createProduct(newProduct);
  }
    afuConfig = {
    uploadAPI: {
      url:"http://localhost:4200"
    }
  };
  readUrl(event:any){
     if(event.target.files && event.target.files[0]){
       var reader=new FileReader();

      //  reader.onload=(event:ProgressEvent)=>{
      //    this.url=(<FileReader>event.target).result;
      //  }
       this.url=event.target.files[0].name;
       reader.readAsDataURL(event.target.files[0]);
        
    }             
  }
  
}
