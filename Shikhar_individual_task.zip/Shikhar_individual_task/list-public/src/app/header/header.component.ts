import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() content:any; // declaring input property for suppling data
  constructor() { }
  ngOnInit(): void {
  }

}
