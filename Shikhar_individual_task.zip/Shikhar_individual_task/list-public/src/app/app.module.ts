import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{HttpClientModule} from'@angular/common/http'; //importing HttpClientModule
import { HomeListComponent } from './home-list/home-list.component';
import { AboutComponent } from './about/about.component';
import { HomepageComponent } from './homepage/homepage.component';
import { HeaderComponent } from './header/header.component';
import { FrameworkComponent } from './framework/framework.component';
import {APP_BASE_HREF}  from '@angular/common';
import { RouterModule } from '@angular/router';
import { CreateComponent } from './create/create.component';
import { DetailsPageComponent } from './details-page/details-page.component';
import { AngularFileUploaderModule } from "angular-file-uploader";
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    HomeListComponent,//Declare HomeListComponent
    AboutComponent, //Declare AboutComponent
    HomepageComponent,//Declare HomePageComponent
    HeaderComponent, ////Declare HeaderComponent
    FrameworkComponent,//Declare FrameworkComponent 
    CreateComponent, //Declare CreateComponent
    DetailsPageComponent //Declare DetailsPageCompnent
  ],
  imports: [
    BrowserModule,
    HttpClientModule, //--Import HttpClientModule
    RouterModule.forRoot([
      {
        path:'',
        component:HomepageComponent //path for homepage
      },
      {
        path:'about',
        component:AboutComponent //path for about page
      },
      {
        path:'home-list',
        component:HomeListComponent
      },
      {
        path:'details-page/:listid',
        component:DetailsPageComponent
      },
      {
        path:'create',
        component:CreateComponent
      }
    ]),
    FormsModule,
    AngularFileUploaderModule
  ],
  providers: [{provide:APP_BASE_HREF,useValue:'/'}],
  bootstrap: [FrameworkComponent]
})
export class AppModule { }
