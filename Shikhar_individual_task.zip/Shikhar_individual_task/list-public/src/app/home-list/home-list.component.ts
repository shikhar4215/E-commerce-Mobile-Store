import { Component, OnInit } from '@angular/core';
import { List } from '../list';
import { ListServiceService } from '../list-service.service';

@Component({
  selector: 'app-home-list',
  templateUrl: './home-list.component.html',
  styleUrls: ['./home-list.component.css'],
  providers:[ListServiceService]
})
export class HomeListComponent implements OnInit {
  list:List[]=[];
  constructor(private listService:ListServiceService) { }

  ngOnInit(): void {
    this.listService
      .getList() //call getList Method from list-service.service
      .then((list:List[]| void)=>{
        this.list=(list as List[]).map(list=>{
          return list;
        });
      });
  }
  pageContent={ 
    header:{
      title:'My Product List',
      body:'This is a list of Product'
    }
  };

}
