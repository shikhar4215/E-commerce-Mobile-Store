import { Injectable } from '@angular/core';
import { List } from './list';
import { HttpClient,HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class ListServiceService {
  [x: string]: any;
  private listUrl='http://localhost:3000/api/list'; //define path
  constructor(private http:HttpClient) { }
    //declare and define getList method
    
    getList():Promise<void|List[]>{
      return this.http.get(this.listUrl)
        .toPromise()
        .then(response=>response as List[])
        .catch(this.handleError);
    }
    private handleError(handleError: any): Promise<void | List[]> {
      throw new Error('Method not implemented.');
    }
   public getSingleProduct(listid:String):Promise<void | List>{
      return this.http.get(this.listUrl+'/'+listid)
        .toPromise()
        .then(response=>response as List)
        .catch(this.handleError1)
    }
  handleError1(handleError1: any): Promise<void | List> {
    throw new Error('Method not implemented.');
  }
  createProduct(newProduct:List):Promise<void | List>{
    return this.http.post(this.listUrl,newProduct)
               .toPromise()
               .then(response=>response as List)
               .catch(this.handleError1)
  }
  deleteProduct(listid:String):Promise<void|List[]>{
    return this.http.delete(this.listUrl+'/'+listid)
        .toPromise()
        .then(response=>response as List[])
        .catch(this.handleError);
    
      
  }
  //updateProduct(listid:String):Promise<void | List>{
  //   const url:string='${this.listUrl}/${listid}';
  //   return this.http
  //     .put(url,{})
  //     .toPromise()
  //     .then(response=>response as List)
  //     .catch(this.handleError1)  
  // }
}
