

const about=function(req,res){
     res.render('about',{title:'About Page'});
 };

 module.exports={
     about
 }
