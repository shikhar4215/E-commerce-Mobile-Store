const index=function(req,res){
    res.render('index',{title:''})
};

module.exports={
    index
}